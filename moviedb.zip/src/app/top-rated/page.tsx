import ListTopRated from "./listTopRated";

export const metadata = {
  title: "TopRated",
};

export default function TopRated() {
  return (
    <div className="min-h-screen">
      <ListTopRated/>
    </div>
  );
}
