import ListUpComing from "./listUpComing";

export const metadata = {
  title: "Upcoming",
};

export default function Upcoming() {
  return (
    <div className="min-h-screen">
      <ListUpComing/>
    </div>
  );
}
