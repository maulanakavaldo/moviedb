export const metadata = {
  title: "Not Found",
};

export default function NotFound() {
  return (
    <div className="min-h-screen">
      <h1 className="text-7xl">Halaman tidak di temukan ...</h1>
    </div>
  );
}
