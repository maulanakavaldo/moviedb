const IMAGES = {
  logoBerijalan: "/img/logo.png",
  sb: "/img/logo.png",
};

export default IMAGES;
